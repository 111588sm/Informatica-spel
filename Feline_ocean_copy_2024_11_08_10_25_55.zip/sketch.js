class Raster {
  constructor(r,k) {
    this.aantalRijen = r;
    this.aantalKolommen = k;
    this.celGrootte = null;
  }
  
  berekenCelGrootte() {
    this.celGrootte = canvas.width / this.aantalKolommen;
  }
  
  teken() {
    push();
    noFill();
    stroke('grey');
    for (var rij = 0;rij < this.aantalRijen;rij++) {
      for (var kolom = 0;kolom < this.aantalKolommen;kolom++) {
        rect(kolom*this.celGrootte,rij*this.celGrootte,this.celGrootte,this.celGrootte);
      }
    }
    pop();
  }
}

class Jos {
  constructor() {
    this.x = 0;
    this.y = 300;
    this.animatie = [];
    this.frameNummer =  3;
    this.stapGrootte = null;
    this.gehaald = false;
    this.levens = 1
  }
  
  beweeg() {
    if (keyIsDown(65)) {
      this.x -= this.stapGrootte;
      this.frameNummer = 2;
    }
    if (keyIsDown(68)) {
      this.x += this.stapGrootte;
      this.frameNummer = 1;
    }
    if (keyIsDown(87)) {
      this.y -= this.stapGrootte;
      this.frameNummer = 4;
    }
    if (keyIsDown(83)) {
      this.y += this.stapGrootte;
      this.frameNummer = 5;
    }
    
    this.x = constrain(this.x,0,canvas.width);
    this.y = constrain(this.y,0,canvas.height - raster.celGrootte);
    
    if (this.x == canvas.width) {
      this.gehaald = true;
    }
  }

  
  wordtGeraakt(vijand) {
    if (this.x == vijand.x && this.y == vijand.y) {
      return true;
    }
    else {
      return false;
    }
  }
  eetAppel(Appelgroen) {
    if (this.x == Appelgroen.x && this.y == Appelgroen.y) {
      return true;
    }
    else{
      return false;
    }
  }
   eetAppel(Appelrood){
    if (this.x == Appelrood.x && this.y == Appelrood.y) {
      return true;
    }
    else {
      return false;
    }
  }
  
bomRaken(bommen) {
    for (let bom of bommen) {
        if (this.x < bom.x + raster.celGrootte &&
            this.x + raster.celGrootte > bom.x &&
            this.y < bom.y + raster.celGrootte &&
            this.y + raster.celGrootte > bom.y) {
            bom.x = 2000;
            return true;
        }
    }
    return false;
}
  
  toon() {
    image(this.animatie[this.frameNummer],this.x,this.y,raster.celGrootte,raster.celGrootte);
  }
  
}

class Roodappel {
    constructor(x,y) {
    this.x = floor(random(0, raster.aantalKolommen)) * raster.celGrootte;
    this.y = floor(random(0, raster.aantalRijen)) * raster.celGrootte;
      this.sprite = null;
      this.stapGrootte = 1 * raster.celGrootte;
    }
  
  toon() {
  image(this.sprite,this.x,this.y,raster.celGrootte,raster.celGrootte);
}
}
  
class Groenappel {
    constructor() {
        this.x = floor(random(1, raster.aantalKolommen - 1)) * raster.celGrootte;
        this.y = floor(random(1, raster.aantalRijen - 1)) * raster.celGrootte;
        this.sprite = null;
        this.stapGrootte = 1 * raster.celGrootte;
        this.directionX = 1; 
        this.directionY = 1; 
    }

    beweeg() {
        this.x += this.directionX * this.stapGrootte; 
        this.y += this.directionY * this.stapGrootte; 

        
        if (this.x <= 0 || this.x >= canvas.width - raster.celGrootte) {
            this.directionX *= -1; 
        }
        if (this.y <= 0 || this.y >= canvas.height - raster.celGrootte) {
            this.directionY *= -1; 
        }
    }

    toon() {
        image(this.sprite, this.x, this.y, raster.celGrootte, raster.celGrootte);
    }
}

class Bom {
    constructor() {
        this.x = floor(random(9, raster.aantalKolommen)) * raster.celGrootte;
        this.y = floor(random(0, raster.aantalRijen - 1)) * raster.celGrootte;
        this.sprite = loadImage("images/sprites/bom.png");
        this.stapGrootte = random(0.1,0.5) * raster.celGrootte;
        this.directionX = 0; 
        this.directionY = 1; 
    }
    
    beweeg() {
        this.x += this.directionX * this.stapGrootte; 
        this.y += this.directionY * this.stapGrootte;
        if (this.x <= 0 || this.x >= canvas.width - raster.celGrootte) {
            this.directionX *= -1; 
        }
        if (this.y <= 0 || this.y >= canvas.height - raster.celGrootte) {
            this.directionY *= -1; 
        }
    }
    
    toon() {
        image(this.sprite, this.x, this.y, raster.celGrootte, raster.celGrootte);
    }
}


class Vijand {
  constructor(x,y) {
    this.x = x;
    this.y = y;
    this.sprite = null;
    this.stapGrootte = null;
  }


  

  beweeg() {
    this.x += floor(random(-1,2))*this.stapGrootte;
    this.y += floor(random(-1,2))*this.stapGrootte;

    this.x = constrain(this.x,0,canvas.width - raster.celGrootte);
    this.y = constrain(this.y,0,canvas.height - raster.celGrootte);
  }
  
  toon() {
    image(this.sprite,this.x,this.y,raster.celGrootte,raster.celGrootte);
  }
}



function preload() {
  brug = loadImage("images/backgrounds/lucht_2.jpg");
  lucht = loadImage("images/backgrounds/lucht_1.jpg");
}

function setup() {
  canvas = createCanvas(900,600);
  canvas.parent();
  frameRate(10);
  textFont("Verdana");
  textSize(90);
  
  
  raster = new Raster(12,18);
  
  raster.berekenCelGrootte();
  
  eve = new Jos();
  eve.stapGrootte = 1*raster.celGrootte;
  for (var b = 0;b < 6;b++) {
    frameEve = loadImage("images/sprites/Eve100px/Eve_" + b + ".png");
    eve.animatie.push(frameEve);
  }
  
  alice = new Vijand(700,200);
  alice.stapGrootte = 1*eve.stapGrootte;
  alice.sprite = loadImage("images/sprites/Alice100px/Alice.png");

  bob = new Vijand(600,400);
  bob.stapGrootte = 1*eve.stapGrootte;
  bob.sprite = loadImage("images/sprites/Bob100px/Bob.png");  


  appelrood = new Roodappel(400,400);
  appelrood.stapGrootte = null;
  appelrood.sprite = loadImage("images/sprites/appel_2.png");
  
  appelgroen = new Groenappel();
  appelgroen.sprite = loadImage("images/sprites/appel_1.png")
  
bommen = [
    new Bom(),
    new Bom(),
    new Bom(),
    new Bom(),
    new Bom(),
  ];
  
  
}

function draw() {
  
  if (mouseY < 50 && mouseY > 0 && mouseX > 0 && mouseX < 900|| mouseX <50 && mouseX > 0 && mouseY > 0 && mouseY < 600){
    background(lucht);
  }
  else{
    background(brug);
  }

  push();
  fill('orange')
  rect(0,0,50,600)
  rect(0,0,900,50)
  pop();
  
  raster.teken();
  eve.beweeg();
  alice.beweeg();
  bob.beweeg();
  eve.toon();
  alice.toon();
  bob.toon();
  appelrood.toon();
  appelgroen.beweeg();
  appelgroen.toon();
  
  for (let bom of bommen) {
  bom.beweeg();
  bom.toon();
  }
  
 push(); 
 fill('black')
  textSize(25);
  text("je hebt nog " + eve.levens + " levens",10,30)
  pop();

  if (eve.gehaald) {
    background('green');
    fill('white');
    text("Je hebt gewonnen!",30,300);
    noLoop();
  }
  
  if (eve.wordtGeraakt(alice) || eve.wordtGeraakt(bob)) {
    eve.levens -= 1;
    if (eve.levens < 0) {
      eve.levens = 0;
    }
  }
  if (eve.bomRaken(bommen)){
    eve.levens -=1;
    if (eve.levens < 0){
      eve.levens = 0;
    }
  }
  
   if (eve.levens === 0) {
    background('red');
    fill('white');
    text("Je hebt verloren", 30, 300);
    noLoop();
  }
  
  if (eve.eetAppel(appelrood)) {
    appelrood.x += 2000;
    eve.levens += 1;
  }
  if (eve.eetAppel(appelgroen)) {
    appelgroen.x += 2000;
    eve.levens +=1
  }

}